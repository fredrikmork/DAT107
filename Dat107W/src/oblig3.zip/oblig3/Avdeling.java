package oblig3;

public class Avdeling {

}
