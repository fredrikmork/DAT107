package oblig3;

import java.util.Iterator;
import java.util.List;


public class Klient {
	public static void main(String[] args) {
		
		AnsattEAO aeao = new AnsattEAO();
		
//		List<Ansatt> ansatte = aeao.finnAlleAnsatte();
//		Iterator<Ansatt> iterator = ansatte.iterator();
//		
//		while(iterator.hasNext()){
//			System.out.println(iterator.next());
		
//		}
		Ansatt a = aeao.finnAnsattMedId(1);
		System.out.println(a);
		aeao.finnAlleAnsatte();
		
	}

}
