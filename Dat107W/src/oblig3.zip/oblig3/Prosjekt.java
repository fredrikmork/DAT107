package oblig3;

public class Prosjekt {

}
