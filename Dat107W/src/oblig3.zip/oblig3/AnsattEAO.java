package oblig3;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;
import javax.persistence.Persistence;

import no.hvl.dat107.forelesning4.Todoliste;

public class AnsattEAO {

	private EntityManagerFactory emf;

	public AnsattEAO() {
		emf = Persistence.createEntityManagerFactory("eclipselink");
	}

	/*
	 * @param et id nummer for en ansatt
	 * 
	 * @return en ansatt med en ID som man selv øsnker å finne
	 */
	public Ansatt finnAnsattMedId(int id) {
		EntityManager em = emf.createEntityManager();

		Ansatt ansattMedId = null;
		try {
			ansattMedId = em.find(Ansatt.class, id);
		} finally {
			em.close();
		}
		return ansattMedId;
	}

	/*
	 * @param et inntastet brukernavn
	 * 
	 * @return gir en ansatt søkt på med brukernavn
	 */
	public Ansatt finnAnsattMedNavn(String brukernavn) {
		EntityManager em = emf.createEntityManager();

		Ansatt ansattMedId = null;
		try {
			ansattMedId = em.find(Ansatt.class, brukernavn);
		} finally {
			em.close();
		}
		return ansattMedId;
	}

	public List<Ansatt> finnAlleAnsatte() {
		EntityManager em = emf.createEntityManager();
		List<Ansatt> ansatte;
		em.getTransaction().begin();
		try {
			ansatte = em.createQuery("SELECT a FROM ansatt a").getResultList();
			em.getTransaction().commit();
		} finally {
			em.close();
		}
		return ansatte;
	}

	/*
	 * @param
	 * 
	 * @return
	 */
	public Ansatt utlistingAvAnsatte() {
		return null;
	}

	/*
	 * @param Nye stilling og lønn for den ansatte
	 * 
	 * @return boolsk verdi på om den ansatte har fått oppdatert stilling og eller
	 * lønn
	 */
	public boolean oppdateringAvAnsatt(String stilling, int månedslønn) {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		try {
			tx.begin();

			// ???

			tx.commit();
		} catch (Throwable e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
		return false;
	}

	/*
	 * @param
	 * 
	 * @return den nye ansatte
	 */
	public Ansatt leggTilAnsatt() {
		return null;
	}

	/*
	 * @param
	 * 
	 * @return
	 */
	public Ansatt sparkeAnsatt() {
		EntityManager em = emf.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		try {
			tx.begin();

			// ???

			tx.commit();
		} catch (Throwable e) {
			e.printStackTrace();
			tx.rollback();
		} finally {
			em.close();
		}
		return null;
	}
}
