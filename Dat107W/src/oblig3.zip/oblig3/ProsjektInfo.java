package oblig3;

public class ProsjektInfo {

}
